<template>
    <div>
        <ul class="share-list aside-sec">
            <li>Wechat</li>
            <li>小红书</li>
            <li>Instagram</li>
        </ul>
        <div class="aside-sec" v-if="columnCate.length > 0">
            <el-menu
                default-active="2"
                class="el-menu-vertical-demo"
                @open="handleOpen"
                @close="handleClose">
                <div v-for="(item,index) in columnCate" :key="index">
                    <div class="cate-name"><span>{{ item.name }}</span></div>
                    <ul class="cate-list">
                        <li @click="cateTap" :data-id="item.id" :class="{active: item.id == curId}"><nuxt-link :to="{path:`/column`, query: {id: item.id}}">全部{{ item.name }}专栏</nuxt-link></li>
                        <li v-for="(sonItem,sonIndex) in item.son" :key="sonIndex" @click="cateTap" :data-id="sonItem.id" :class="{active: sonItem.id == curId}">
                            <nuxt-link :to="{path:`/column`, query: {id: sonItem.id}}">{{ sonItem.name }}</nuxt-link>
                        </li>
                    </ul>
                </div>
            </el-menu>
        </div>
        <div class="label-wrap aside-sec">
            <div class="name">标签</div>
            <ul class="label-list">
                <li><nuxt-link :to="`/column?q=新手养宠`">新手养宠</nuxt-link></li>
                <li><nuxt-link :to="`/column?q=礼品上新`">礼品上新</nuxt-link></li>
                <li><nuxt-link :to="`/column?q=新手养宠应该注意什么？`">新手养宠应该注意什么？</nuxt-link></li>
                <li><nuxt-link :to="`/column?q=十大热门宠物`">十大热门宠物</nuxt-link></li>
            </ul>
        </div>
        
    </div>
</template>

<script>
import { mapState } from 'vuex'
export default {
    data(){
        return {
            cateData: [],
            curId: 0
        }
    },
    computed: {
        ...mapState('cate', ['columnCate'])
    },
    created(){
        // this.curId = this.$route.params.id
        // columnModel.getSonCate()
        //     .then(res => {
        //         this.cateData = res
        //     })
    },
    methods: {
        handleOpen(key, keyPath) {
            console.log(key, keyPath);
        },
        handleClose(key, keyPath) {
            console.log(key, keyPath);
        },
        cateTap(e){
            const id = e.currentTarget.dataset.id
            this.curId = id
        },
    },
}
</script>

<style lang="less">
   
   .nav-name{
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 20px;
        font-weight: bold;
        padding: 10px 0 10px;
        margin-top: 20px;
        border-top: 3px solid #cbcbcb;
        span{
            display: inline-block;
            width: 20px;
            height: 3px;
            background-color: #cbcbcb;
            margin-right: 16px;
        }
    }
    
    .el-menu{
        border-right: 0!important;
    }
   
    .cate-name{
        position: relative;
        margin: 10px 0 6px;
        &::before{
            content: '';
            display: block;
            position: absolute;
            border-bottom: 1px solid #cbcbcb;
            left: 0;
            top: 50%;
            height: 0;
            width: 100%;
        }
        span{
            position: relative;
            z-index: 1;
            background-color: #fff;
            padding-right: 9px;
            font-size: 16px;
            font-weight: bold;
        }
    }
    .cate-list{
        line-height: 2;
        li.active{
            a{
                opacity: 0.6;
            }
        }
    }

    .aside-sec{
        margin-bottom: 20px;
        padding-bottom: 20px;
        border-bottom: #ccc 1px solid;
    }
    .label-wrap{
        .name{
            margin-bottom: 20px;
            font-weight: bold;
        }
        .label-list{
            display: flex;
            flex-wrap: wrap;
        }
        li{
            display: flex;
            align-items: center;
            height: 28px;
            line-height: 1;
            padding: 0 15px;
            margin: 5px 10px 5px 0;
            border: 1px solid #707070;
            border-radius: 3px;
        }
    }
    .share-list{
        li{
            line-height: 1.8;
        }
    }

</style>

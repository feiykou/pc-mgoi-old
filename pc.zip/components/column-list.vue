<template>
    <ul class="list-wrap" v-if="columnData.length > 0">
        <li v-for="(item, index) in columnData" :key="index">
            <div class="img hover-class">
                <nuxt-link :to="`/column/${item.id}`"><img :src="item.main_img_url[0]" alt=""></nuxt-link>
            </div>
            <p class="date">{{ formalDate(item.create_time) }}</p>
            <p class="tit hover-class"><nuxt-link :to="`/column/${item.id}`">{{ item.name }}</nuxt-link></p>
            <p class="line"></p>
            <p class="label">{{ item.sub_name }}</p>
        </li>
    </ul>
</template>

<script>
import columnModel from '@/service/column'
export default {
    data(){
        return {
        };
    },
    created(){
    },
    props: {
        columnData: Array
    },
    methods: {
        formalDate(val){
            const index = val.indexOf(' ');
            return val.substring(0,index);
        }
    }
}
</script>

<style lang="less" scoped>
.list-wrap{
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    li{
        width: 48%;
        border-bottom: 1px solid #707070;
        padding-bottom: 50px;
        margin-bottom: 50px;
        &:nth-child(2n-1){
            margin-right: 30px;
        }
    }
    .img{
        height: 302px;
        background-color: #eee;
        img{
            width: 100%;
            height: 100%;
        }
    }
    .date{
        margin-top: 20px;
        color: #b2b2b2;
    }
    .tit{
        margin-top: 10px;
    }
    .line{
        margin: 32px 0;
        height: 2px;
        width: 80px;
        background-color: #707070;
    }
}
</style>

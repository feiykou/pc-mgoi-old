<template>
    <div class="contact-container container">
        <ul class="contact-list">
            <li>企业名称：唔该深圳文化创意有限公司</li>
            <li>地址：深圳市南山区科技创业园</li>
            <li>邮箱：mgoisaai@163.com</li>
            <li>电话：0755 - 33551100</li>
        </ul>
    </div>
</template>

<script>
export default {

}
</script>

<style lang="less" scoped>
    .container{
        margin: 40px 0 80px;
    }
    .contact-list{
        li{
            display: flex;
            align-items: center;
            box-sizing: border-box;
            height: 74px;
            padding: 28px 60px 0;
            border-bottom: 1px solid #707070;
        }
    }
</style>
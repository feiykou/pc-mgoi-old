<template>
    <div class="container">
        <div class="content news-content">
            <el-breadcrumb separator-class="el-icon-arrow-right">
                <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
                <el-breadcrumb-item>关于唔该</el-breadcrumb-item>
            </el-breadcrumb>
            <h1 class="title">关于唔该</h1>
            <div class="about-wrap">
                <el-tabs v-model="activeName" @tab-click="handleClick">
                    <el-tab-pane label="唔该理念" name="about">
                        <div class="about-item">
                            <nuxt-child></nuxt-child>
                        </div>
                    </el-tab-pane>
                    <el-tab-pane label="唔该新闻" name="news">
                        <nuxt-child name="news"></nuxt-child>
                    </el-tab-pane>
                    <el-tab-pane label="唔该招聘" name="recruit"><nuxt-child name="recruit"></nuxt-child></el-tab-pane>
                    <el-tab-pane label="联系唔该" name="contact"><nuxt-child name="contact"></nuxt-child></el-tab-pane>
                </el-tabs>
            </div>
        </div>
    </div>
</template>

<script>
import Header from '@/components/v-header/index.vue';
export default {
    data() {
      return {
        activeName: 'about'
      };
    },
    created() {
        this.setTab(this.$route.hash)
    },
    watch: {
        '$route': function(route){
            const hash = route.hash
            this.setTab(hash)
        }
    },
    methods: {
        handleClick(tab, event) {
            this.activeName = tab.name
        },
        setTab(hash){
            if(!hash) return;
            let tabName = ''
            switch(hash){
                case '#news':
                    tabName = 'news'
                    break;
                case '#recruit':
                    tabName = 'recruit'
                    break;
                case '#contact':
                    tabName = 'contact'
                    break;
                default:
                    tabName = 'about'
            }
            this.activeName = tabName
        }
    },
    components: {
        Header
    }
}
</script>

<style lang="less">
    .news-content{
        padding-bottom: 80px;
    }
    h1.title{
        font-size: 28px;
        margin-bottom: 100px;
    }
    .about-wrap{
        padding: 0 70px;
        .about-item{
            margin-top: 80px;
        }
        .el-tabs__nav{
            display: flex;
            float: none!important;
            justify-content: space-between;
            background-color: #eee;
            .el-tabs__active-bar{
                display: none;
            }
            &>div.el-tabs__item{
                display: flex;
                justify-content: center;
                align-items: center;
                height: 72px;
                width: 260px;
                padding: 0;
                border-bottom: 2px solid #eee;
                font-size: 18px;
                font-weight: bold;
                &:nth-last-child(1){
                    border-right: 0;
                }
                &.is-active{
                    border-bottom: 2px solid #000;
                    color: #000!important;
                }
                &:hover{
                    color: #000!important;
                }
            }
        }
    }
</style>
<template>
    <div class="news-container container">
        <ul class="news-list" v-if="!newsDetail">
            <li class="news-item" v-for="(item, index) in newsData" :key="index">
                <div class="img">
                    <a href="javascript:void(0);" @click="newsClick" :data-id="item.id"><img :src="item.main_img_url[0]" alt=""></a>
                </div>
                <div class="con">
                    <div class="tit"><a href="javascript:void(0);" @click="newsClick" :data-id="item.id">{{ item.name }}</a></div>
                    <p class="description">{{ item.description }}</p>
                    <p class="btn btn-animate btn-gray"><a href="javascript:void(0);" @click="newsClick" :data-id="item.id">查看详情</a></p>
                </div>
            </li>
        </ul>
        <div class="news-detail" v-else>
            <el-breadcrumb separator-class="el-icon-arrow-right">
                <el-breadcrumb-item><span @click="backNewsClick">新闻</span></el-breadcrumb-item>
                <el-breadcrumb-item>{{ newsDetail.name }}</el-breadcrumb-item>
            </el-breadcrumb>
            <p class="date">{{ formalDate(newsDetail.create_time) }}</p>
            <h1>{{ newsDetail.name }}</h1>
            <div class="con" v-html="newsDetail.content"></div>
        </div>
    </div>
</template>

<script>
import newsModel from '@/service/news'
export default {
    data() {
        return {
            newsData: [],
            newsDetail: null
        }
    },
    created() {
        this.getAllNews()
    },
    methods: {
        getAllNews(){
            this.newsDetail = null
            newsModel.getAllNews()
                .then(res => {
                    console.log(res)
                    this.newsData = res.data
                })
        },
        getNewsDetail(id){
            newsModel.getNewsDetail(id)
                .then(res => {
                    console.log(res)
                    this.newsDetail = res
                })
        },
        newsClick(e){
            const id = e.currentTarget.dataset.id
            this.getNewsDetail(id)
        },
        formalDate(val){
            const index = val.indexOf(' ');
            return val.substring(0,index);
        },
        backNewsClick(){
            this.newsDetail = null
        }
    },
}
</script>

<style lang="less" scoped>
    .el-breadcrumb__item{
        cursor: pointer;
    }
    .container{
        margin-top: 80px;
    }
    .news-item{
        display: flex;
        padding-bottom: 80px;
        margin-bottom: 80px;
        border-bottom: 1px solid #000;
        &:nth-last-child(1){
            border-bottom: 0;
            margin-bottom: 0;
        }
        .img{
            flex: 0 0 540px;
            width: 540px;
            height: 378px;
            background-color: #eee;
            img{
                width: 100%;
                height: 100%;
            }
        }
        .con{
            flex: 1;
            padding-left: 60px;
            .tit{
                font-size: 28px;
                font-weight: bold;
                margin: 35px 0;
            }
            .description{
                padding: 0 60px 0 68px;
                line-height: 1.6;
                &::before{
                    content: '';
                    position: relative;
                    top: -5px;
                    display: inline-block;
                    width: 48px;
                    margin-right: 20px;
                    height: 2px;
                    margin-left: -68px;
                    background-color: #707070;
                }
            }
            .btn{
                display: flex;
                justify-content: center;
                align-items: center;
                width: 245px;
                height: 50px;
                margin-top: 50px;
                border: 1px solid #707070;
                border-radius: 3px;
                font-size: 18px;
                font-weight: bold;
            }
        }
    }
    .date{
        margin-top: 20px;
    }
    .news-detail{
        flex: 1;
        padding-bottom: 100px;
        h1{
            font-size: 30px;
            margin: 30px 0 60px;
        }
        .edit{
            margin-bottom: 40px;
        }
        .head-img{
            height: 720px;
            background-color: #eee;
            margin-bottom: 100px;
        }
        .con{
            line-height: 1.6;
        }
    }
    
</style>
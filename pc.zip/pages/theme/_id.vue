<template>
    <div class="container" v-if="productData">
        <transition name="animated" enter-active-class="animated fadeInUp" appear :duration="2000">
        <div class="content detail-content">
            <el-breadcrumb separator-class="el-icon-arrow-right">
                <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
                <el-breadcrumb-item :to="{ path: '/product' }">主题列表</el-breadcrumb-item>
                <el-breadcrumb-item>{{ productData.name }}</el-breadcrumb-item>
            </el-breadcrumb>
            <div class="product-main-section">
                <div class="detail-banner">
                    <div class="banner-wrap">
                        <el-carousel :interval="5000" height="640px" :setActiveItem="currentIndex" indicator-position="none" arrow="always" @change="bannerChange" ref="banner">
                            <el-carousel-item v-for="(item,index) in productData.imgs_url" :key="index">
                                <img :src="item" alt="" srcset="">
                            </el-carousel-item>
                        </el-carousel>
                    </div>
                    <ul class="banner-indicator">
                        <li v-for="(item,index) in productData.imgs_url" :key="index" :class="{active: index==currentIndex}" @click="dotTap" :data-index="index">
                            <img :src="item" alt="" srcset="">
                        </li>
                    </ul>
                </div>
                <div class="product-info">
                    <h1 class="title">{{ productData.name }}</h1>
                    <p class="price">{{ productData.price }}元</p>
                    <div class="info">
                        <p><span>介绍：</span>{{ productData.introduce }}</p>
                        <p><span>商品编号：</span>999999999</p>
                        <p><span>在库情况：</span>{{ productData.stock > 0 ? '有货' : '缺货' }}</p>
                    </div>
                    <div class="prop-list-wrap">
                        <template v-if="propVal.length">
                            <dl class="prop-item" v-for="(item, index) in propVal" :key="index">
                                <dd class="prop">
                                    <span>{{ item }}</span>
                                </dd>
                                <dt class="btn-animate btn-primary" @click="buyBtnTap">立即购买</dt>
                            </dl>
                        </template>
                        <template v-else>
                            <div class="btn-animate btn-primary buy-btn" @click="buyBtnTap">立即购买</div>
                        </template>
                    </div>
                    <div class="btn-wrap">
                        <el-button class="btn btn-animate btn-gray btn-share" v-popover:popover2>分享</el-button>
                    </div>
                </div>
            </div>
            <div class="product-detail-section">
                <div class="detail-wrap">
                    <el-tabs v-model="activeName" @tab-click="handleClick">
                        <el-tab-pane label="商品的基本信息" name="first">
                            <h2 class="h2-tit">商品说明</h2>
                            <div class="product-info" v-html="productData.content"></div>
                        </el-tab-pane>
                        <el-tab-pane label="产品的规格" name="second">配置管理</el-tab-pane>
                        <el-tab-pane label="注意事项" name="third">角色管理</el-tab-pane>
                    </el-tabs>
                </div>
            </div>
            <div class="resc-wrap" v-if="rescProduct.length > 0">
                <product-list title="推荐产品" :productData="rescProduct" :showAll="false"></product-list>
            </div>
        </div>
        </transition>
        <el-dialog
            :visible.sync="centerDialogVisible"
            width="28%"
            center>
            <ul class="buy-type">
                <li><a :href="productData.link_url?productData.link_url:'javascript:volid(0);'" target="_blank"><img src="@/assets/taobao.png">端跳转至淘宝</a></li>
                <li class="wx-buy-btn"><el-button v-popover:wx><img src="@/assets/wx.png">小程序购买</el-button></li>
                <li><a href="javascript:volid(0);" target="_blank"><img src="@/assets/redBook.png">小红书购买</a></li>
            </ul>
            <el-popover
                ref="wx"
                placement="left"
                title=""
                width="200"
                trigger="hover"
                content="">
                <div class="code-wrap">
                    <img :src="productData.code_img" alt="" srcset="">
                    <p>（微信扫一扫 进行支付）</p>
                </div>
            </el-popover>
        </el-dialog>
        <el-popover
            ref="popover2"
            placement="top"
            width="200"
            trigger="click"
            content="">
            <ul class="share-info-list">
                <li>微博</li>
                <li>小红书</li>
                <li>头条</li>
            </ul>
        </el-popover>
    </div>
</template>

<script>
import ProductList from '@/components/index/v-product-list/index.vue';
import themeModel from '@/service/theme'
import productModel from '@/service/product'

export default {
    validate({ params }) {
        return /^\d+$/.test(params.id) // 参数无效，Nuxt.js 停止渲染当前页面并显示错误页面
    },
    data() {
      return {
        activeName: 'first',
        themeData: null,
        productData: null,
        currentIndex: 0,
        propVal: [],
        centerDialogVisible: false
      };
    },
    created() {
    },
    async asyncData({ params, error }) {
        const id = Number(params.id)

        let [
            themeData, 
            rescProduct
        ] = await Promise.all([
            themeModel.getThemeDetail(id),
            productModel.getRescProduct(5,5,id)
        ])

        let productData = themeData.product

        let propVal = []
        if(productData && productData['prop'] && productData['prop'].length > 0){
            let prop_value = productData['prop'][0]['prop_value']
            if(prop_value) propVal = prop_value.split(',')
        }

        if(!productData) error({ statusCode: 404, message: '页面加载失败，请重新加载' })
        return {
            productData,
            rescProduct,
            propVal
        }
    },
    head(){
        return this.$seo(`唔该`,'正处于萌芽阶段')
    },
    methods: {
        buyBtnTap(e){
            this.centerDialogVisible = !this.centerDialogVisible
        },
        dotTap(e){
            const index = e.currentTarget.dataset.index
            this.currentIndex = Number(index)
            this.$refs.banner.setActiveItem(this.currentIndex)
        },
        bannerChange(index){
            this.currentIndex = Number(index)
        },
        handleClick(tab, event) {
            console.log(tab, event);
        }
    },
    components: {
        ProductList
    }
}
</script>


<style lang="less">
    
    .detail-content{
        padding-bottom: 100px;
    }
    // 面包屑
    .el-breadcrumb{
        display: flex;
        align-items: center;
        height: 100px;
    }
    // 详情信息
    .product-main-section{
        display: flex;
        .product-info{
            flex: 1;
            padding: 40px 0 0 112px;
        }
        .title{
            font-size: 26px;
            margin-bottom: 0;
            font-weight: normal;
        }
        .price{
            font-size: 24px;
            font-weight: bold;
        }
        .info{
            line-height: 1.8;
            font-size: 12px;
            margin-top: 5px;
            span{
                font-weight: bold;
            }
        }
        .prop-list-wrap{
            margin-top: 80px;
        }
        .prop-item{
            display: flex;
            align-items: center;
            justify-content: space-between;
            height: 98px;
            border-top: 1px solid #e1e1e1;
            border-bottom: 1px solid #e1e1e1;
            img{
                width: 50px;
                height: 50px;
                margin-right: 20px;
            }
            .prop{
                display: flex;
                align-items: center;
                font-weight: bold;
            }
            dt{
                display: flex;
                justify-content: center;
                align-items: center;
                width: 150px;
                height: 38px;
                line-height: 1;
                background-color: #32a2c5;
                color: #fff;
                border-radius: 5px;
            }
        }
        // 购买按钮
        .buy-btn{
            display: flex;
            justify-content: center;
            align-items: center;
            width: 150px;
            height: 38px;
            line-height: 1;
            background-color: #32a2c5;
            color: #fff;
            border-radius: 5px;
        }
        // 分享
        .btn-wrap{
            margin-top: 110px;
            .btn{
                display: flex;
                justify-content: center;
                align-items: center;
                height: 48px;
                border: 1px solid #707070;
                border-radius: 5px;
            }
            .btn-share{
                width: 100%;
                color: #333;
                &:focus{
                    background-color: #fff;
                }
            }
        }
        
    }
    // 轮播
    .detail-banner{
        width: 720px;
        flex: 0 0 720px;
        margin-bottom: 36px;
        img{
            width: 100%;
            height: 100%;
        }
        .banner-wrap{
            background-color: #eee;
        }
        .banner-indicator{
            display: flex;
            margin-top: 30px;
            li{
                width: 70px;
                height: 70px;
                margin-right: 20px;
                background-color: #fbfbfb;
                border: 4px solid #fbfbfb;
                &.active{
                    border-color: #e2e2e2;
                }
            }
        }
    }
    // 产品详情
    .detail-wrap{
        width: 720px;
        padding: 36px 0;
        .el-tabs__nav{
            display: flex;
            float: none!important;
            justify-content: space-between;
            
            .el-tabs__active-bar{
                display: none;
            }
            &>div.el-tabs__item{
                display: flex;
                justify-content: center;
                align-items: center;
                height: 72px;
                flex: 1;
                padding: 0;
                background-color: #eee;
                border-right: 2px solid #fff;
                border-bottom: 2px solid #eee;
                font-size: 16px;
                font-weight: bold;
                -webkit-transition: none .2s cubic-bezier(.215,.61,.355,1);
                transition: none .2s cubic-bezier(.215,.61,.355,1);
                -webkit-transition-property: opacity;
                transition-property: opacity;
                &:nth-last-child(1){
                    border-right: 0;
                }
                &.is-active{
                    border-bottom: 2px solid #000;
                    color: #000!important;
                }
                &:hover{
                    color: #000!important;
                    -webkit-transition: none .2s cubic-bezier(.215,.61,.355,1);
                    transition: none .2s cubic-bezier(.215,.61,.355,1);
                    -webkit-transition-property: opacity;
                    transition-property: opacity;
                    opacity: 0.5;
                }
            }
        }
        .h2-tit{
            margin: 36px 0;
            font-size: 18px;
        }
        p.text{
            line-height: 1.6;
        }
    }
    .resc-wrap{
        margin-top: 80px;
        padding: 60px 0 100px;
        border-top: 1px solid #E1E1E1;
    }
    
    .el-dialog{
        border: 1px solid #707070;
    }
    .buy-type{
        margin: 0 20px;
        li{
            height: 120px;
            color: #000;
            font-size: 18px;
            border-bottom: 1px solid #707070;
            padding: 0 50px;
            &:nth-last-child(1){
                border-bottom: 0;
            }
            img{
                width: 40px;
                height: auto;
                margin-right: 50px;
            }
            a{
                display: flex;
                align-items: center;
                height: 100%;
            }
        }
    }
    .wx-buy-btn{
        button{            
            width: 100%;
            height: 100%;
            background-color: #fff!important;
            color: #333!important;
            padding: 0;
            text-align: left;
            border: 0;
            span{
                display: flex;
                align-items: center;
                font-size: 18px;
                color: #333;
                -webkit-transition: none 0.2s cubic-bezier(0.215, 0.61, 0.355, 1);
                transition: none 0.2s cubic-bezier(0.215, 0.61, 0.355, 1);
                -webkit-transition-property: opacity;
                transition-property: opacity;
                &:hover{
                    opacity: 0.6;
                    -webkit-transition: none 0.2s cubic-bezier(0.215, 0.61, 0.355, 1);
                    transition: none 0.2s cubic-bezier(0.215, 0.61, 0.355, 1);
                    -webkit-transition-property: opacity;
                    transition-property: opacity;
                }
            }
        }
    }
    .share-info-list{
        display: flex;
        li{
            margin: 0 10px;
        }
    }
    .code-wrap{
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        color: #999;
        img{
            width: 80px;
            height: 80px;
            margin-bottom: 10px;
        }
    }
    
</style>


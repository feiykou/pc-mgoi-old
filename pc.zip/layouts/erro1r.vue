<template>
  <div class="container">
    <div class="error-content">
        <h1>对不起，121212没有相应的页面</h1>
        <nuxt-link to="/" class="click-class">点击此处</nuxt-link>前往唔该首页
    </div>
  </div>
</template>

<script>
export default {
  props: ['error']
}
</script>

<style lang="less" scoped>
    .container{
        display: flex;
        align-items: center;
        justify-content: center;
        min-height: 600px;
    }
    .error-content{
        border: 1px solid #000;
        padding: 45px 150px;
        font-size: 28px;
        box-shadow: 2px 3px 3px #eee;
    }
    h1{
        font-size: 28px;
    }
    .click-class{
        text-decoration: underline;
        color: #32a2c5;
    }
</style>

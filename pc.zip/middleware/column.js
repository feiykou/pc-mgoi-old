export default function ( {app} ) {
    console.log(1)
}
import api from './api'

export default {

    getIndexBanner(){
		return api.fetchGet('index/banner');
	},

    // 上新产品
	getNewsProduct(){
        return api.fetchGet('index/newsProduct');
    },
    
    // 猫咪和狗狗推荐产品
    getCateRescProduct(cateId,rescId=1){
        return api.fetchGet(`product/rescbycate?cateId=${cateId}&rescId=${rescId}`);      
    },

    getCateRescColumn(cateId,rescId=1){
        return api.fetchGet(`column/indexResc?cateId=${cateId}&rescId=${rescId}`);
    },    
    
    // 获取礼物分类
    getGiftCate(cateId=98){
        return api.fetchGet( `giftCate/resc?cateId=${cateId}`);
    },

    // 获取菜单分类数据
    getMenuCate(cateId=0){
        return api.fetchGet( `cate/sonAllCate/${cateId}`);
    },

    // 获取菜单分类数据
    getRescTheme(rescId=1){
        return api.fetchGet( `index/rescTheme?rescId=${rescId}`);
    }

}
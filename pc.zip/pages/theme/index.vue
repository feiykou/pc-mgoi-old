<template>
    <div class="container">
        <div class="content main-section">
            <div class="cate-wrap menu-left-wrap">
                <Menu></Menu>
            </div>
            <div class="product-section">
                <el-breadcrumb separator-class="el-icon-arrow-right">
                    <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
                    <el-breadcrumb-item class="crumb-item" @click.native="crumbTap" :data-index="index" v-for="(item,index) in crumbArr" :key="index">{{item.name}}</el-breadcrumb-item>
                </el-breadcrumb>

                <div class="product-wrap">

                    <div class="theme-wrap">
                        <div class="title">猫的场景</div>
                        <ul class="theme-list">
                            <li v-for="(item, index) in dogData" :key="index">
                                <div class="img">
                                    <nuxt-link :to="`/theme/${item.id}`"><img :src="item.main_img_url[0]" alt=""></nuxt-link>
                                </div>
                                <p class="tit"><nuxt-link :to="`/theme/${item.id}`">{{ item.name }}</nuxt-link></p>
                                <p class="desc">{{ item.description }}</p>
                            </li>
                        </ul>
                    </div>
                    
                    <div class="theme-wrap">
                        <div class="title">狗的场景</div>
                        <ul class="theme-list">
                            <li v-for="(item, index) in catData" :key="index">
                                <div class="img">
                                    <nuxt-link :to="`/theme/${item.id}`"><img :src="item.main_img_url[0]" alt=""></nuxt-link>
                                </div>
                                <p class="tit"><nuxt-link :to="`/theme/${item.id}`">{{ item.name }}</nuxt-link></p>
                                <p class="desc">{{ item.description }}</p>
                            </li>
                        </ul>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import Menu from '@/components/v-menu/index.vue'
import themeModel from '@/service/theme'

export default {
    data(){
        return {
            catData: [],
            dogData: [],
            crumbArr: [{name: '产品分类', id: 0}],
            curName: '产品分类'
        }
    },
    components: {
        Menu
    },
    created(){
    },
    async asyncData({isDev, route, store, env, params, query, req, res, redirect, error}) {
        let [catData, dogData] = await Promise.all([
            themeModel.getThemeList(3),
            themeModel.getThemeList(4)
        ]);

        if(!catData) error({ statusCode: 404, message: '页面加载失败，请重新加载' })

        return {
           catData,
           dogData
        }
    },
    fetch({ store }){
        return store.dispatch('cate/getProductCate')
    },
    methods: {

    }
}
</script>

<style lang="less" scoped>

    // 面包屑
    .el-breadcrumb{
        display: flex;
        height: 90px;
        align-items: center;
        .crumb-item{
            cursor: pointer;
        }
    }

    .main-section{
        display: flex;
    }
    .menu-left-wrap{
        margin-top: 20px;
    }
    .product-section{
        flex: 1;
        padding-left: 42px;
    }

    .theme-wrap{
        &:nth-child(1){
            border-bottom: 1px solid #707070;
            margin-bottom: 80px;
        }
        .title{
            font-size: 28px;
            margin: 50px 0 60px;
            text-align: center;
        }
        .theme-list{
            display: flex;
            li{
                width: 320px;
                padding-bottom: 60px;
                border-right: 2px solid #fff;
                &:nth-child(3n){
                    border-right: 0;
                }
                .img{
                    width: 100%;
                    height: 238px;
                    background-color: #eee;
                    img{
                        width: 100%;
                        height: 100%;
                    }
                }
                .tit{
                    font-size: 20px;
                    margin: 20px 0 30px;
                    padding: 0 15px;
                }
                .desc{
                    line-height: 1.6;
                    padding: 0 10px;
                }
            }
        }
    }

   
</style>

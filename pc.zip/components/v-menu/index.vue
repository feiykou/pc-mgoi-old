<template>
    <div class="menu-box">
        <ul class="list-item">
            <li>
                <router-link to="/theme">猫的场景</router-link>
            </li>
            <li>
                <router-link to="/theme">狗的场景</router-link>
            </li>
        </ul>
        <el-menu
            default-active="2"
            class="el-menu-vertical-demo"
            @open="handleOpen"
            @close="handleClose">
            <div v-for="(item,index) in productCate" :key="index">
                <div class="nav-name">{{ item.name }}<span></span></div>
                <div class="group-wrap" v-for="(sonItem,sonIndex) in item.son" :key="sonIndex">
                    <div class="cate-name"><span>{{ sonItem.name }}</span></div>
                    <el-submenu :index="index + '-' + sonIndex+'-'+ssIndex" class="cate-list-wrap" v-for="(ssItem, ssIndex) in sonItem.son" :key="ssIndex">
                        <template slot="title">
                            <span slot="title">{{ ssItem.name }}</span>
                        </template>
                        <el-menu-item :index="index + '-' + sonIndex+'-'+ssIndex+'-100'"><nuxt-link :to="{name: `product`,query: {id:ssItem.id, name: ssItem.name}}">情感的全部产品</nuxt-link></el-menu-item>
                        <el-menu-item :index="index + '-' + sonIndex+'-'+ssIndex+'-'+sssIndex" v-for="(sssItem, sssIndex) in ssItem.son" :key="sssIndex"><nuxt-link :to="{name: `product`,query: {id:sssItem.id, name: sssItem.name}}">- {{ sssItem.name }}</nuxt-link></el-menu-item>
                    </el-submenu>
                </div>
            </div>
        </el-menu>
    </div>
</template>

<script>
import { mapState } from 'vuex'
export default {
    data(){
        return {
            cateData: []
        }
    },
    created(){
        console.log(2)
    },
    computed: {
        ...mapState('cate', ['productCate'])
    },
    methods: {
        handleOpen(key, keyPath) {
            this.$emit('menuTap')
            console.log(key, keyPath)
        },
        handleClose(key, keyPath) {
            this.$emit('menuTap')
            console.log(key, keyPath);
        }
    },
}
</script>

<style lang="less">

    .menu-box{
        margin-top: 20px;
        max-height: 900px;
        overflow-y: auto;
        overflow-x: hidden
    }

    .list-item{
        padding: 20px 0;
        margin-bottom: -20px;
        border-top: 1px solid #cbcbcb;
        li{
            line-height: 2;
        }
    }

    .nav-name{
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 20px;
        font-weight: bold;
        padding: 10px 0 10px;
        margin-top: 20px;
        border-top: 3px solid #cbcbcb;
        span{
            display: inline-block;
            width: 20px;
            height: 3px;
            background-color: #cbcbcb;
            margin-right: 16px;
        }
    }
   
    .el-menu{
        border-right: 0!important;
        &::before{
            display: block!important;
        }
    }
    // 打开的菜单
    .is-opened{
        .el-submenu__title{
            background-color: #000!important;
            color: #fff;
            padding-left: 7px!important;
            transition: all .3s;
        }
    }
    .el-submenu__title:hover {
        padding-left: 7px!important;
        transition: all .3s;
    }
    .nav-list-top{
        &::after{
            content: '';
            display: block;
            height: 0;
            // border-bottom: 1px solid #cbcbcb;
            margin: 12px 0;
        }
    }
    .cate-list-wrap{
        li{
            padding: 0 0 0 14px!important;
            &:first-child{
                padding: 0 0 0 7px!important;
            }
        }
    }
    .cate-name{
        position: relative;
        margin: 10px 0 6px;
        &::before{
            content: '';
            display: block;
            position: absolute;
            border-bottom: 1px solid #cbcbcb;
            left: 0;
            top: 50%;
            height: 0;
            width: 100%;
        }
        span{
            position: relative;
            z-index: 1;
            background-color: #fff;
            padding-right: 9px;
            font-size: 16px;
            font-weight: bold;
        }
    }
    .el-menu-item, .el-submenu__title{
        height: 30px!important;
        line-height: 30px!important;
        text-align: left;
        padding-left: 0!important;
        transition: all .3s!important;
        a{
            display: block;
        }
    }

</style>

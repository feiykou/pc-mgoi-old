<template>
    <div class="banner">
        <el-carousel :interval="5000" arrow="card" height="666px" @change="bannerChange">
            <el-carousel-item v-for="(item, index) in bannerData" :key="index">
                <div class="hover-class">
                    <img class="g-img" :src="item.thumb_url" alt="" srcset="">
                </div>
            </el-carousel-item>
        </el-carousel>
        <div class="dot-wrap">
            <ul class="dots">
                <li v-for="(item) in bannerData.length" :key="item">
                    <i v-if="curIndex == item-1" :style="{transform: 'translate3d(-'+width+'%,0,0)'}"></i>
                </li>
            </ul>
        </div>
    </div>
</template>

<script>
let timer = null
export default {
    data(){
        return {
            curIndex: 0,
            width: 100
        }
    },
    props: {
        bannerData: Array
    },
    created(){
        this.aniateWidth()
    },
    methods: {
        bannerChange(index){
            this.curIndex = index
            this.aniateWidth()
        },
        aniateWidth(){
            this.width = 100
            clearInterval(timer)
            const speed = 2
            let width = 100
            timer = setInterval(() => {
                width = width - speed
                if(width <=0){
                    width=0
                    clearInterval(timer)
                }
                this.width = width
            },20)
        }
    }
}
</script>

<style lang="less" scoped>
    .dot-wrap{
        display: flex;
        justify-content: center;
        margin: 30px 0;
        .dots{
            display: flex;
        }
        li{
            position: relative;
            width: 256px;
            height: 2px;
            margin: 0 10px;
            background-color: #C0C4CC;
            overflow: hidden;
            i{
                position: absolute;
                left: 0;
                width: 100%;
                height: 2px;
                top: 0;
                transform: translate3d(-100%,0,0);
                background-color: #707070;
            }
        }
    }
    .banner{
        overflow: hidden;
        padding-bottom: 60px;
        .el-carousel--horizontal{
            position: relative;
            width: 1340px!important;
            margin: 0 auto;
            overflow: visible!important;
            &::before{
                content: '';
                z-index: 2;
                display: block;
                width: 100vw;
                height: 100%;
                background-color: rgba(255,255,255,.8);
                position: absolute;
                top: 0;
                left: -100vw;
            }
            &::after{
                content: '';
                z-index: 2;
                display: block;
                width: 100vw;
                height: 100%;
                background-color: rgba(255,255,255,.8);
                position: absolute;
                top: 0;
                left: 100%;
            }
        }
        .el-carousel__indicators{
            padding-top: 30px;
            white-space: nowrap;
        }
        .el-carousel__button{
            background-color: #707070!important;
            width: 265px!important;
            margin: 0 10px!important;
        }
        
        .el-carousel__item:nth-child(2n) {
            background-color: #99a9bf;
        }
        
        .el-carousel__item:nth-child(2n+1) {
            background-color: #d3dce6;
        }
    }
</style>

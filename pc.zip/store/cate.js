import {
    UPDATE_COLUMN_CATE,
    UPDATE_PRODUCT_CATE,
    UPDATE_PARENT_CATE
} from './mutations-type'

import columnModel from '@/service/column'
import api from '@/service/index'
import productModel from '@/service/product'

export const state = () => ({
    columnCate: [],
    productCate: [],
    crumbCate: []
})

export const mutations = {
    [UPDATE_COLUMN_CATE] (state,data) {
        state.columnCate = data
    },
    [UPDATE_PRODUCT_CATE] (state, data) {
        state.productCate = data
    },
    [UPDATE_PARENT_CATE] (state, data) {
        state.crumbCate = data
    }
}

export const actions = {
    async getColumnCate ({ commit }) {
        try {
            let columnCate =  await columnModel.getSonCate();
            commit(UPDATE_COLUMN_CATE, columnCate)
            return Promise.resolve(columnCate)
        } catch (error) {
            return Promise.reject(error)
        }
    },
    async getProductCate ({ commit }) {
        try {
            let productCate =  await api.getMenuCate();
            commit(UPDATE_PRODUCT_CATE, productCate)
            return Promise.resolve(productCate)
        } catch (error) {
            return Promise.reject(error)
        }
    },
    async getParentCate ({ commit }, id) {
        try {
            let crumbCate =  await productModel.getParentCate(id);
            commit(UPDATE_PARENT_CATE, crumbCate)
            return Promise.resolve(crumbCate)
        } catch (error) {
            return Promise.reject(error)
        }
    }
}
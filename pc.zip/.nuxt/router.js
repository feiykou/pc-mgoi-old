import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _6e0b0c53 = () => interopDefault(import('..\\pages\\about\\index.vue' /* webpackChunkName: "pages_about_index" */))
const _03f95662 = () => interopDefault(import('..\\pages\\about\\index\\index.vue' /* webpackChunkName: "pages_about_index_index" */))
const _3ba58b4f = () => interopDefault(import('..\\components\\about\\contact.vue' /* webpackChunkName: "components_contact" */))
const _1250f6b4 = () => interopDefault(import('..\\components\\about\\news.vue' /* webpackChunkName: "components_news" */))
const _67b42f6d = () => interopDefault(import('..\\components\\about\\recruit.vue' /* webpackChunkName: "components_recruit" */))
const _5e795d04 = () => interopDefault(import('..\\pages\\column\\index.vue' /* webpackChunkName: "pages_column_index" */))
const _7f940d78 = () => interopDefault(import('..\\pages\\column\\index\\index.vue' /* webpackChunkName: "pages_column_index_index" */))
const _522becc9 = () => interopDefault(import('..\\components\\column-list.vue' /* webpackChunkName: "components_column-list" */))
const _4b00b79e = () => interopDefault(import('..\\pages\\product\\index.vue' /* webpackChunkName: "pages_product_index" */))
const _135d0054 = () => interopDefault(import('..\\pages\\search.vue' /* webpackChunkName: "pages_search" */))
const _e64f86d2 = () => interopDefault(import('..\\pages\\theme\\index.vue' /* webpackChunkName: "pages_theme_index" */))
const _27539b66 = () => interopDefault(import('..\\pages\\column\\_id.vue' /* webpackChunkName: "pages_column__id" */))
const _d54a024e = () => interopDefault(import('..\\pages\\product\\_id.vue' /* webpackChunkName: "pages_product__id" */))
const _1daa78bf = () => interopDefault(import('..\\pages\\theme\\_id.vue' /* webpackChunkName: "pages_theme__id" */))
const _f2ee47d8 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages_index" */))

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
      path: "/about",
      component: _6e0b0c53,
      children: [{
        path: "",
        components: {
          default: _03f95662,
          contact: _3ba58b4f,
          news: _1250f6b4,
          recruit: _67b42f6d
        },
        name: "about-index"
      }]
    }, {
      path: "/column",
      component: _5e795d04,
      children: [{
        path: "",
        components: {
          default: _7f940d78,
          columnList: _522becc9
        },
        name: "column-index"
      }]
    }, {
      path: "/product",
      component: _4b00b79e,
      name: "product"
    }, {
      path: "/search",
      component: _135d0054,
      name: "search"
    }, {
      path: "/theme",
      component: _e64f86d2,
      name: "theme"
    }, {
      path: "/column/:id",
      component: _27539b66,
      name: "column-id"
    }, {
      path: "/product/:id",
      component: _d54a024e,
      name: "product-id"
    }, {
      path: "/theme/:id",
      component: _1daa78bf,
      name: "theme-id"
    }, {
      path: "/",
      component: _f2ee47d8,
      name: "index"
    }],

  fallback: false
}

export function createRouter() {
  return new Router(routerOptions)
}

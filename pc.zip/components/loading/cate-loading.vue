<template>
    <div class="cate-box">
        <div class="cate-loader">
            <content-loader
                :height="134"
                :width="125"
                :speed="2"
                primaryColor="#d4d4d4"
                secondaryColor="#ecebeb"
            >
                <rect x="47" y="17" rx="0" ry="0" width="28" height="14" /> 
                <rect x="38.5" y="46" rx="0" ry="0" width="46" height="46" /> 
                <rect x="0" y="128.27" rx="0" ry="0" width="125" height="1" />
            </content-loader>
        </div>
        <div class="cate-loader">
            <content-loader
                :height="134"
                :width="125"
                :speed="2"
                primaryColor="#d4d4d4"
                secondaryColor="#ecebeb"
            >
                <rect x="47" y="17" rx="0" ry="0" width="28" height="14" /> 
                <rect x="38.5" y="46" rx="0" ry="0" width="46" height="46" /> 
                <rect x="0" y="128.27" rx="0" ry="0" width="125" height="1" />
            </content-loader>
        </div>
        <div class="cate-loader">
            <content-loader
                :height="134"
                :width="125"
                :speed="2"
                primaryColor="#d4d4d4"
                secondaryColor="#ecebeb"
            >
                <rect x="47" y="17" rx="0" ry="0" width="28" height="14" /> 
                <rect x="38.5" y="46" rx="0" ry="0" width="46" height="46" /> 
                <rect x="0" y="128.27" rx="0" ry="0" width="125" height="1" />
            </content-loader>
        </div>
        <div class="cate-loader">
            <content-loader
                :height="134"
                :width="125"
                :speed="2"
                primaryColor="#d4d4d4"
                secondaryColor="#ecebeb"
            >
                <rect x="47" y="17" rx="0" ry="0" width="28" height="14" /> 
                <rect x="38.5" y="46" rx="0" ry="0" width="46" height="46" /> 
                <rect x="0" y="128.27" rx="0" ry="0" width="125" height="1" />
            </content-loader>
        </div>
    </div>
</template>

<script>
import {
  ContentLoader,
} from 'vue-content-loader'
export default {
    components: {
        ContentLoader
    }
}
</script>

<style lang='less'>
    .cate-box{
        display: flex;
    }
    .cate-loader{
        width: 125px;
        height: 134px;
        margin-right: 20px;
        margin-top: 50px;
    }
</style>

<template>
    <div class="header">
        <div class="content header-box">
            <div class="logo-wrap">
                <nuxt-link to="/"><img src="@/static/images/logo.png" alt="" srcset=""></nuxt-link>
            </div>
            <div class="nav-wrap">
                <ul class="list-nav">
                    <li v-for="(item, index) in tabnav" :key="index">
                        <nuxt-link v-if="item.ename != 'search'" :to="item.url" :class="{active: curname == item.ename}">{{ item.name }}</nuxt-link>
                        <el-input
                            v-else
                            placeholder="请输入内容"
                            prefix-icon="el-icon-search"
                            @keyup.enter.native="enterSearch"
                            v-model="search">
                        </el-input>
                    </li>
                </ul>
            </div>
            <div class="gift-wrap"></div>
        </div>
    </div>
</template>

<script>
import { mapState } from 'vuex'
export default {
    data(){
        return {
            search: '',
            curName: '',
            tabnav: [
                {
                    name: '首页',
                    url: '/',
                    ename: 'index'
                },
                {
                    name: '产品分类',
                    url: '/product',
                    ename: 'product'
                },
                {
                    name: '唔该专栏',
                    url: '/column',
                    ename: 'column'
                },
                {
                    name: '唔该主题',
                    url: '/theme',
                    ename: 'theme'
                },
                {
                    name: '关于唔该',
                    url: '/about',
                    ename: 'about'
                },
                {
                    ename: 'search'
                }
            ]
        }
    },
    computed: {
        ...mapState('nav',['curname'])
    },
    created(){
        // let name = this.$route.name
        // if(!name) name = 'home'
        // this.curName = name
    },
    methods: {
        enterSearch(){
            if(!this.search) return;
            this.$router.push({path: '/search',query: {q: this.search}})
        }
    }
}
</script>

<style lang="less" scoped>
    .header{
        border-bottom: 1px solid #ddd;
        .header-box{
            display: flex;
            align-items: center;
            height: 148px;
        }
        .logo-wrap{
            width: 259px;
            flex: 0 0 259px;
            text-align: left;
            font-size: 32px;
        }
        .list-nav{
            display: flex;
            align-items: center;
            flex: 1;
            &>li{
                margin: 0 25px;
                .router-link-exact-active,.active{
                    opacity: 0.5;
                }

            }
        }
    }
    .el-input__inner:focus{
        border-color:#32a2c5!important;
    }
</style>

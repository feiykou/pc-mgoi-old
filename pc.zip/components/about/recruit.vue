<template>
    <div class="recruit-container container">
        <ul class="recruit-list">
            <li class="list-item">
                <div class="tit">工业设计师</div>
                <div class="con">
                    <p class="name">职位介绍</p>
                    <p class="p">重视人物，宠物之间的相互联结重视人物，宠物之间的相互联结重视人物，宠物之间的相互联结重视人物，宠物之间的相互联结重视人物，宠物之间的相互联结重视人物，宠物之间的相互联结重视人物，宠物之间的相互联结</p>
                    <p class="p">重视人物，宠物之间的相互联结重视人物，宠物之间的相互联结重视人物，宠物之间的相互联结重视人物，宠物之间的相互联结重视人物，宠物之间的相互联结重视人物，宠物之间的相互联结重视人物，宠物之间的相互联结</p>
                    <p class="p">重视人物，宠物之间的相互联结重视人物，宠物之间的相互联结重视人物，宠物之间的相互联结重视人物，宠物之间的相互联结重视人物，宠物之间的相互联结重视人物，宠物之间的相互联结重视人物，宠物之间的相互联结</p>
                    <p class="p">重视人物，宠物之间的相互联结重视人物，宠物之间的相互联结重视人物，宠物之间的相互联结重视人物，宠物之间的相互联结重视人物，宠物之间的相互联结重视人物，宠物之间的相互联结重视人物，宠物之间的相互联结</p>
                </div>
            </li>
        </ul>
    </div>
</template>

<script>
export default {

}
</script>

<style lang="less" scoped>
    .container{
        margin-top: 30px;
    }

    .list-item{
        margin: 50px 0;
        .tit{
            display: flex;
            align-items: center;
            height: 100px;
            padding-left: 200px;
            font-size: 24px;
            border-bottom: 1px solid #707070;
        }
        .con{
           padding: 40px 200px; 
           .name{
               margin: 10px 0;
               font-size: 18px;
               font-weight: bold;
           }
           .p{
               margin-top: 20px;
           }
        }
    }
</style>

<template>
    <div class="con">
        <div class="img-wrap img">
            <img :src="cateData.img_url[1]" alt="">
        </div>
        <div class="info-product">
            <div class="info">
                <div class="img-txt">
                    <img :src="cateData.img_url[0]" alt="">
                    <div class="txt">
                        <span class="name">{{ cateData.name }}</span>
                        <span class="desc">与节日有关的信息</span>
                    </div>
                </div> 
                <ul class="product-list">
                    <li v-for="(item, index) in cateData.product_cate" :key="index" class="img">
                        <img v-lazy="item.main_img_url[0]" alt="" srcset="">
                    </li>
                </ul>
            </div>
            <div class="description">
                {{ cateData.introduce }}
            </div>
        </div>
    </div>
</template>

<script>
export default {
    props: {
        cateData: Object
    }
}
</script>

<style lang="less" scoped>
    .img img{
        width: 100%;
        height: 100%;
    }
    .con{
        .description{
            padding-right: 238px;
            line-height: 2;
            letter-spacing: .08em;
        }
        .info{
            display: flex;
            justify-content: space-between;
            margin-top: 60px;
            .product-list{
                width: 298px;
                display: flex;
                flex-wrap: wrap;
                justify-content: flex-end;
                li{
                    width: 96px;
                    height: 96px;
                    background-color: #eee;
                    margin: 0 0 10px 10px;
                }
            }
        }
        .img-wrap{
            height: 376px;
            background-color: #eee;
        }
        .img-txt{
            display: flex;
            margin: 0 60px 40px 0; 
            img{
                width: 170px;
                height: 157px;
            }
            .txt{
                display: flex;
                flex-direction: column;
                padding: 35px 0 0 76px;
            }
            span{
                &.name{
                    font-size: 24px;
                }
                &.desc{
                    margin-top: 5px;
                    font-size: 12px;
                }
            }
        }
    }
</style>

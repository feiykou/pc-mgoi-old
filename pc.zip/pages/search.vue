<template>
    <div class="container">
        <div class="content search-section">
            <div class="cate-wrap menu-left-wrap">
                <Menu></Menu>
            </div>
            <transition name="slide-fade" appear :duration="2000">
            <div class="product-section">
                <div class="product-wrap">
                    <div class="filter-wrap">
                        <div class="product-num">搜索详情</div>
                        <dl class="filter-list">
                            <dt>排序方式：</dt>
                            <dd :class="{active: curPriceIndex == 1}" @click="priceSort" :data-index='1'>价格高至低</dd>
                            <dd :class="{active: curPriceIndex == 2}" @click="priceSort" :data-index='2'>价格低至高</dd>
                        </dl>
                    </div>
                    <div class="product-list">
                        <ul class="product-item" v-if="productsData">
                            <li v-for="(item, index) in productsData" :key="index">
                                <nuxt-link :to="{path: `/product/`+item.id}">
                                    <div class="img hover-class">
                                        <img :src="item.main_img_url[0]" alt="" srcset="">
                                    </div>
                                    <p class="tit hover-class" v-html="str_replace(item.name)"></p>
                                    <p class="label">{{ item.name_desc }}</p>
                                    <p class="price">{{ item.price }}元</p>
                                    <div class="btn btn-animate btn-primary">立即购买</div>
                                </nuxt-link>
                            </li>
                            <li></li>
                            <li></li>
                            <li></li>
                        </ul>
                        <ProductListLoading v-else></ProductListLoading>
                    </div>
                    <div class="pagination-wrap">
                        <el-pagination
                            background
                            layout="prev, pager, next"
                            :total="2">
                        </el-pagination>
                    </div>
                    
                </div>
            </div>
            </transition>
        </div>
    </div>
</template>

<script>
import Menu from '@/components/v-menu/index.vue'

import CateLoading from '@/components/loading/cate-loading.vue'
import ProductListLoading from '@/components/loading/product-list-loading.vue'

import productModel from '@/service/product'
import { setTimeout } from 'timers';

import { mapState } from 'vuex'

export default {
    watchQuery: ['q'],
    data(){
        return {
            productsData: [],
            q: '',
            curPriceIndex: 0
        }
    },
    components: {
        Menu,
        CateLoading,
        ProductListLoading
    },
    async asyncData({ query, error }) {
        const q = query.q
        let productsData = []
        if(q=='undefined'){
            return {
                productsData: []
            }
        }
        productsData = await productModel.searchResult(q)
        return {
            productsData: productsData.data,
            q
        }
    },
    fetch({ store }){
        return store.dispatch('cate/getProductCate')
    },
    head(){
        return this.$seo('产品列表 - 唔该','正处于萌芽阶段')
    },
    created(){
        console.log(1)
    },

    methods: {
        priceSort(e){
            const index = e.currentTarget.dataset.index
            this.curPriceIndex = index
            if(!this.q) return;
            this.getProducts(this.q, index)
        },
        getProducts(q='', sort=0){
            this.productsData = []
            productModel.searchResult(q,sort)
                .then(res => {
                    setTimeout(() => {
                        this.productsData = res.data
                    }, 600)
                })
        },
        str_replace(name){
            return name.replace(this.q,`<span>${this.q}</span>`)
        }
    }
}
</script>

<style lang="less">
    
    // 分页
    .pagination-wrap{
        text-align: center;
        margin-bottom: 80px;
    }

    // 产品列表
    .product-item{
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        li{
            width: 222px;
            margin-bottom: 69px;
            .img{
                height: 222px;
                background-color: #eee;
                img{
                    width: 100%;
                    height: 100%;
                }
            }
            .tit{
                margin-top: 16px;
                span{
                    color: #32a2c5;
                    font-weight: bold;
                }
            }
            .label{
                font-size: 12px;
                color: #989898;
            }
            .price{
                margin: 10px 0 30px;
                font-weight: bold;
                color: #555;
                font-size: 12px;
            }
            .btn{
                display: flex;
                justify-content: center;
                align-items: center;
                height: 40px;
                color: #32a2c5;
                border-radius: 5px;
                border: 1px solid #32a2c5;
            }
        }
    }
    .search-section{
        display: flex;
        margin-top: 60px;
        .filter-wrap{
            margin: 30px 0 60px;
        }
    }
    // 排序
    .filter-wrap{
        display: flex;
        justify-content: space-between;
        align-items: center;
        height: 50px;
        .product-num{
            font-size: 28px;
            font-weight: bold;
        }
        .filter-list{
            display: flex;
            dt{
                font-weight: bold;
                margin-right: 10px;
            }
            dd{
                margin-right: 20px;
                cursor: pointer;
                &.active,&:hover{
                    color: #32a2c5;
                }
            }
        }
    }

    .product-section{
        flex: 1;
        padding-left: 42px;
    }

    // 分页
    .el-pager li.active{
        background-color: #32a2c5!important;
    }
</style>

<template>
    <div class="column-container" v-if="detailData">
        <el-breadcrumb class="crumb-wrap" separator-class="el-icon-arrow-right">
            <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
            <el-breadcrumb-item :to="{ path: '/column' }">专栏列表</el-breadcrumb-item>
            <el-breadcrumb-item>{{ detailData.name }}</el-breadcrumb-item>
        </el-breadcrumb>
        <div class="content column-detail-content">
            <div class="menu-wrap">
                <column-menu></column-menu>
            </div>
            <div class="section">                
                <p class="date">{{ formalDate(detailData.create_time) }}</p>
                <h1>{{ detailData.name }}</h1>
                <p class="edit">编辑：{{ detailData.author }}</p>
                <div class="con" v-html="detailData.content"></div>
                <div class="topBottom-wrap" v-if="topBottomData">
                    <div class="item">
                        <span class="label">上一篇：</span>
                        <router-link :to="`/column/detail/${topBottomData.prev_info.id}`" v-if="topBottomData.prev_info">{{ topBottomData.prev_info.name }}</router-link>
                        <span v-else>没有了</span>
                    </div>
                    <div class="item">
                        <span class="label">下一篇：</span>
                        <router-link :to="`/column/detail/${topBottomData.next_info.id}`" v-if="topBottomData.next_info">{{ topBottomData.next_info.name }}</router-link>
                        <span v-else>没有了</span>
                    </div>
                </div>


                <div class="news-column-wrap">
                    <div class="title"><span>相关推荐</span></div>
                    <ul class="list-wrap">
                        <li v-for="(item,index) in rescData" :key="index">
                            <div class="img hover-class">
                                <nuxt-link :to="`/column/${item.id}`"><img :src="item.main_img_url[0]" alt=""></nuxt-link>
                            </div>
                            <div class="info">
                                <p class="date">{{ formalDate(item.create_time) }}</p>
                                <p class="tit"><nuxt-link :to="`/column/${item.id}`">{{ item.name }}</nuxt-link></p>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import ColumnMenu from '@/components/v-column-menu/index.vue';
import columnModel from '@/service/column'
export default {
    components: {
        ColumnMenu
    },
    data(){
        return {
            detailData: null,
            topBottomData: null,
            rescData: [],
            curId: 0
        }
    },
    async asyncData({ params, error }) {
        const id = Number(params.id),
            detailData = await columnModel.getColumnDetail(id)
        if(!detailData) error({ statusCode: 404, message: '页面加载失败，请重新加载' })
        return {
            detailData
        }
    },
    fetch({ store }){
        return store.dispatch('cate/getColumnCate')
    },
    head(){
        return this.$seo(`${this.detailData.name} - 唔该`,'正处于萌芽阶段')
    },
    validate({ params }) {
        return /^\d+$/.test(params.id) // 参数无效，Nuxt.js 停止渲染当前页面并显示错误页面
    },
    created() {
        this.curId = Number(this.$route.params.id)
        this._loadData()
    },
    watch: {
        '$route': function(to,from){
            this.curId = to.params.id
            this._loadData()
        }
    },
    methods: {
        _loadData(){
            this.getTopBottom(this.curId)
            this.getRescData()
        },
        getTopBottom(id){
            columnModel.getTopBottomData(id)
                .then(res => {
                    console.log(res)
                    this.topBottomData = res
                })
        },
        getRescData(){
            // 3：相关推荐  4：展示个数
            columnModel.getRescColumn(3,4,this.curId)
                .then(res => {
                    this.rescData = res
                })
        },
        formalDate(val){
            const index = val.indexOf(' ');
            return val.substring(0,index);
        }
    },
}
</script>

<style lang="less" scoped>

    .topBottom-wrap{
        margin: 60px 0;
        border-top: 1px solid #e1e1e1;
        padding-top: 30px;
        .item{
            margin-bottom: 20px;
            &:nth-child(1){
                margin-right: 100px;
            }
            .label{
                font-weight: bold;
            }
        }
    }

    .crumb-wrap{
        width: 1200px;
        margin: 30px auto 20px;
    }
    .news-column-wrap{
        margin: 100px 0;
        .title{
            height: 12px;
            line-height: 1;
            margin-bottom: 80px;
            border-bottom: 2px solid #707070;
            font-size: 24px;
            span{
                background-color: #fff;
                padding-right: 48px;
            }
        }
        .list-wrap{
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            li{
                width: 48%;
                display: flex;
                border-bottom: 1px solid #707070;
                padding-bottom: 45px;
                margin-bottom: 45px;
            }
            .img{
                width: 210px;
                flex: 0 0 210px;
                height: 124px;
                background-color: #eee;
                img{
                    width: 100%;
                    height: 100%;
                }
            }
            .info{
                flex: 1;
                margin-left: 30px;
            }
            .date{
                margin-top: 20px;
            }
            .tit{
                margin-top: 10px;
                font-weight: bold;
            }
        }
    }
    .column-detail-content{
        display: flex;
        padding-top: 30px;
    }
    .menu-wrap{
        width: 254px;
        flex: 0 0 254px;
        .label-wrap{
            .name{
                margin-bottom: 30px;
                font-weight: bold;
            }
            .label-list{
                display: flex;
                flex-wrap: wrap;
            }
            li{
                display: flex;
                align-items: center;
                height: 28px;
                padding: 0 15px;
                margin: 0 10px 10px 0;
                border: 1px solid #707070;
                border-radius: 3px;
            }
        }
        .share-list{
            li{
                line-height: 1.8;
            }
        }
    }
    .aside-sec{
        padding: 25px 0;
        border-bottom: 1px solid #707070;
    }
    .section{
        flex: 1;
        padding-left: 60px;
        h1{
            font-size: 30px;
            margin: 30px 0 60px;
        }
        .edit{
            margin-bottom: 40px;
        }
        .head-img{
            height: 720px;
            background-color: #eee;
            margin-bottom: 100px;
        }
        .con{
            line-height: 1.6;
        }
    }
</style>

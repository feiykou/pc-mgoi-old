<template>
    <div class="container">
        <Banner :bannerData="bannerData"></Banner>
        <div class="content section-box">
            <div class="theme-resc">
                <div class="title">主题推荐</div>
                <el-carousel :interval="5000" :arrow="rescThemeData.length > 1 ? 'always': 'never'" height="389px" indicator-position="outside">
                    <el-carousel-item v-for="(item, index) in rescThemeData" :key="index">
                        <ul class="resc-list" v-if="!item.seize">
                            <li v-for="(sitem,sindex) in item" :key="sindex" class="hover-class">
                                <nuxt-link :to="{path:`/theme/${sitem.id}`}"><img :src="sitem.main_img_url" alt="" srcset=""></nuxt-link>
                            </li>
                        </ul>
                    </el-carousel-item>
                </el-carousel>
            </div>
            <div class="product-container">
                <div class="cate-wrap menu-left-wrap" id="menu-fixed">
                    <div :class="{'is_fixed': isFixed}" id="menu-box">
                        <Menu @menuTap="onMenuTap"></Menu>
                    </div>
                </div>
                <div class="product-section">
                    <product-list title="上新产品" :productData="newsProductData"></product-list>
                    <div class="line"></div>
                    <product-list title="猫咪产品" :curCateId="91" :productData="catProductData"></product-list>
                    <div class="line"></div>
                    <product-list title="狗狗产品" :curCateId="90" :productData="dogProductData"></product-list>
                    <div class="line"></div>
                    <column-list title="猫咪专栏" :curCateId="7" :columnData="catColumnData"></column-list>
                    <div class="line"></div>
                    <column-list title="狗狗专栏" :curCateId="8" :columnData="dogColumnData"></column-list>
                </div>
            </div>
        </div>
        <div class="cate-btn-entry" id="cate-product-btn">
            <div class="title">宠物产品</div>
            <div class="btn-wrap">
                <div class="btn btn-animate btn-gray">狗的产品</div>
                <div class="btn btn-animate btn-gray">猫的产品</div>
            </div>
        </div>
        
        <div class="gift-cate-section content">
            <div class="tit">分类</div>
            <div class="gift-cate-wrap">
                <div class="gift-cate-box">
                    <div v-for="(item,index) in giftCateData" :key="index">
                        <gift-cate :cateData="item"></gift-cate>
                        <div class="small-line"></div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="company-section">

        </div>
        
    </div>
</template>

<script>

import Menu from '@/components/v-menu/index.vue';
import ProductList from '@/components/index/v-product-list/index.vue';
import ColumnList from '@/components/index/v-column-list/index.vue';
import GiftCate from '@/components/index/v-gift-cate/index.vue';
import Banner from '@/components/index/banner.vue';
import { mapGetters,mapActions } from 'vuex'

import api from '@/service/index'

import { gridGroup } from '@/static/js/common.js'


export default {
    components: {
        Menu,
        ProductList,
        ColumnList,
        GiftCate,
        Banner
    },
    data(){
        return {
            bannerData: [],
            rescThemeData: [],
            newsProductData: [],
            catProductData: [],
            dogProductData: [],
            catColumnData: [],
            dogColumnData: [],
            giftCateData: [],
            columnNum: 4, // 主题分组一组数量
            isFixed: false,
            offsetTop:0,
            menuHeight: 0,
            cateOffsetTop: 0
        }
    },
    mounted(){
        window.addEventListener('scroll',this.initHeight);
        this.$nextTick( () => {
            this.setMenuScroll()
            console.log(2)
        })
    },
    fetch({ store }){
        return store.dispatch('cate/getProductCate')
    },
    head(){
        return this.$seo('唔该','正处于萌芽阶段')
    },
    async asyncData ({ error }) {
        let [
            bannerData, 
            rescThemeData, 
            newsProductData, 
            catProductData, 
            dogProductData,
            catColumnData,
            dogColumnData,
            giftCateData
        ] = await Promise.all([
            api.getIndexBanner(), 
            api.getRescTheme(),
            api.getNewsProduct(),
            api.getCateRescProduct(91),
            api.getCateRescProduct(90),
            api.getCateRescColumn(7),
            api.getCateRescColumn(8),
            api.getGiftCate(98)
        ])
        rescThemeData = gridGroup(rescThemeData)
        if(!bannerData) error({ statusCode: 404, message: '页面加载失败，请重新加载' })
        return { 
            bannerData, 
            rescThemeData, 
            newsProductData, 
            catProductData, 
            dogProductData,
            catColumnData,
            dogColumnData,
            giftCateData
        }
    },
    created() {
    },
    methods: {
        initHeight () {
            var scrollTop = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop
            if(scrollTop > this.offsetTop && scrollTop < this.cateOffsetTop - this.menuHeight - 100){
                this.isFixed = true
            } else {
                this.isFixed = false
            }
        },
        onMenuTap(){
            setTimeout(()=>{
                this.menuHeight = document.querySelector('#menu-box').clientHeight;
            },200)
        },
        setMenuScroll(){
            this.offsetTop = document.querySelector('#menu-fixed').offsetTop;
            this.menuHeight = document.querySelector('#menu-box').clientHeight;
            this.cateOffsetTop = document.querySelector('#cate-product-btn').offsetTop;
        },
    },
    computed: {
        ...mapGetters([
            'getCurname'
        ])
    },
}
</script>

<style lang="less">

    .is_fixed{
        position: fixed;
        top: 50px;
        width: 196px;
        z-index: 999;
    }

    .g-img{
        width: 100%;
        height: 100%;
    }

    .company-section{
        height: 775px;
        background-color: #eee;
    }

    .gift-cate-section{
        .tit{
            font-size: 28px;
            font-weight: bold;
            margin: 66px 0 110px -80px;
        }
    }

    // 公共线
    .line{
        height: 2px;
        margin: 80px 0;
        background-color: #707070;
    }
    .small-line{
        height: 1px;
        margin: 80px 0;
        background-color: #d4d4d4;
    }

    .product-container{
        display: flex;
        margin-top: 100px;
        
    }

   
    
    .section-box{
        padding: 100px 0;
    }
    .theme-resc{
        .title{
            font-size: 20px;
            font-weight: bold;
            text-align: left;
        }
        .resc-list{
            display: flex;
            justify-content: space-between;
            height: 100%;
            margin-top: 30px;
            &>li{
                width: 270px;
                height: 100%;
                img{
                    width: 100%;
                    height: 100%;
                }
            }
        }

        .el-carousel__indicators{
            padding-top: 30px;
            white-space: nowrap;
        }
        .el-carousel__button{
            background-color: #707070!important;
            width: 265px!important;
            margin: 0 10px!important;
        }
        // .el-carousel__arrow--right{
        //     right: -54px;
        // }
        // .el-carousel__arrow--left{
        //     left: -54px;
        // }
        
    }

    // 分类菜单
    .cate-wrap{
        min-height: 1000px;
    }

    .product-section{
        flex: 1;
        padding-left: 55px;
    }

    // 产品分类进入按钮
    .cate-btn-entry{
        background-color: #eee;
        padding: 85px 0 112px;
        .title{
            font-size: 28px;
            text-align: center;
            color: #a6a6a6;
        }
        .btn-wrap{
            display: flex;
            justify-content: center;
            margin-top: 56px;
            .btn{
                display: flex;
                justify-content: center;
                align-items: center;
                width: 502px;
                height: 80px;
                margin: 0 39px;
                border: 1px solid #707070;
                border-radius: 5px;
                font-size: 20px;
                font-weight: bold;
            }
        }
    }

    .gift-cate-wrap{
        width: 1100px;
        margin: 0 auto;
    }
    
    
</style>
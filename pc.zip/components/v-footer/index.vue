<template>
    <div class="footer">
        <div class="share-wrap">
            <img src="@/static/images/share@icon.png" alt="" srcset="">
        </div>
        <div class="content">
            <ul class="buy-info">
                <li>
                    <div class="tit">用户指南</div>
                    <p>
                        在这里有详细的用户使用指南
                    </p>
                </li>
                <li>
                    <div class="tit">关于送礼</div>
                    <p>
                        在这里有详细的用户使用指南
                    </p>
                </li>
                <li>
                    <div class="tit">关于购买方式</div>
                    <p>
                        唔该为大家提供了三种购买方式，可以淘宝直接购买，可以小程序购买，可以用小红书购买
                    </p>
                </li>
            </ul>
            <div class="company-sec">
                <ul class="info-list">
                    <li><nuxt-link to="/about#recruit">招聘信息</nuxt-link></li>
                    <li><nuxt-link to="/column">唔该专栏</nuxt-link></li>
                    <li><nuxt-link to="/about#news">唔该新闻</nuxt-link></li>
                </ul>
                <div class="logo-info">
                    <div class="copy">
                        <p>版权所有@2018-2019</p>
                        <p>唔该保留所有权利</p>
                    </div>
                    <div class="logo">LOGO</div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {

}
</script>

<style lang="less">
    .footer{
        background-color: #eee;
    }
    .share-wrap{
        display: flex;
        justify-content: center;
        padding-top: 72px;
    }
    .buy-info{
        display: flex;
        margin-top: 50px;
        li{
            flex: 1;
            margin-right: 30px;
            &:nth-last-child(1){
                margin-right: 0;
            }
            p{
                margin: 10px 0;
            }
        }
        .tit{
            display: flex;
            align-items: center;
            height: 42px;
            font-size: 16px;
            font-weight: bold;
            border-bottom: 1px solid #b8b8b8;
        }
    }
    .company-sec{
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-top: 100px;
        padding: 60px 0;
        border-top: 1px solid #b1b1b1;
        .info-list{
            display: flex;
            li{
                margin-right: 56px;
            }
        }
        .logo-info{
            display: flex;
            align-items: center;
            .logo{
                font-size: 16px;
                font-weight: bold;
                margin-left: 40px;
            }
        }
    }
</style>

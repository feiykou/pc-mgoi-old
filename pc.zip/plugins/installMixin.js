import Vue from 'vue';

Vue.mixin({
    created() {
        console.log('通过插件的安装的行为')
    }
})
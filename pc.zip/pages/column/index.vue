<template>
    <div class="column-container">
        <div class="content column-content"  v-if="headRescData.length > 0">
            <el-breadcrumb separator-class="el-icon-arrow-right">
                <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
                <el-breadcrumb-item>专栏列表</el-breadcrumb-item>
            </el-breadcrumb>
            <div class="column-top-resc" v-for="(item, index) in headRescData" :key="index">
                <div class="img">
                    <img :src="item.main_img_url[0]" alt="">
                </div>
                <div class="info">
                    <p class="date">{{ formalDate(item.create_time) }}</p>
                    <div class="tit">{{ item.name }}</div>
                </div>
            </div>
            <div class="lr-section">
                <div class="menu-left-wrap menu-wrap">
                    <column-menu></column-menu>
                </div>
                <div class="column-section">
                    <div class="news-column-wrap">
                        <div class="title"><span>专栏列表</span></div>
                        <template v-if="columnData">
                            <nuxt-child :columnData="columnData" name="columnList"></nuxt-child>
                        </template>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
</template>

<script>
import ColumnMenu from '@/components/v-column-menu/index.vue';
import columnModel from '@/service/column'


import { mapActions } from 'vuex'

export default {    
    watchQuery: ['id'],
    components: {
        ColumnMenu
    },
    data(){
        return {
            headRescData: [],
            cateId: 0
        };
    },
    created(options){
        this.$store.dispatch('cate/getColumnCate')
        if(this.$route.query.q){
            this.search(this.$route.query.q)
        }
    },
    head(){
        return this.$seo(`专栏列表 - 唔该`,'正处于萌芽阶段')
    },
    computed: {
        id() {
            return Number(this.$route.query.id)
        }
    },
    async asyncData({query, error}) {
        const headRescData = await columnModel.getRescColumn(),
            cateId = query.id | 0,
            columnData = await columnModel.getColumns(cateId)
        if(!columnData) error({ statusCode: 404, message: '页面加载失败，请重新加载' })
        return {
            headRescData,
            columnData: columnData.data
        }
    },
    fetch({ store }){
        return store.dispatch('cate/getColumnCate')
    },
    watch: {
        '$route': function(to,from){
            if(to.query.q){
                this.search(to.query.q)
            }
        }
    },
    methods: {
        formalDate(val){
            const index = val.indexOf(' ');
            return val.substring(0,index);
        },
        search(q){
            columnModel.search(q)
                .then(res => {
                    this.columnData = res.data
                })
        },
        // ...mapActions([
        //     'cate', ['getColumnCate']
        // ])
    }
}
</script>

<style lang="less">
    .column-content{
        width: 1200px!important;
    }
    .lr-section{
        display: flex;
        margin-top: 100px;
    }
    .column-section{
        flex: 1;
        padding-left: 55px;
    }
    .news-column-wrap{
        .title{
            height: 12px;
            line-height: 1;
            margin-bottom: 80px;
            border-bottom: 2px solid #707070;
            font-size: 24px;
            span{
                background-color: #fff;
                padding-right: 48px;
            }
        }
    }
    .column-top-resc{
        display: flex;
        align-items: center;
        .img{
            width: 966px;
            height: 460px;
            background-color: #eee;    
            img{
                width: 100%;
                height: 100%;
            }        
        }
        .info{
            width: 256px;
            padding: 50px 72px;
            margin-left: -124px;
            background-color: #fff;
            box-shadow: 0 2px 3px #eee;
            .date{
                margin-bottom: 10px;
                color: #b2b2b2;
            }
            .tit{
                font-size: 28px;
                line-height: 1.8;
            }
        }
    }
    .menu-wrap{
        width: 254px;
        flex: 0 0 254px;
        
    }
</style>

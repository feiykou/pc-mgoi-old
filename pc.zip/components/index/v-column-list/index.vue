<template>
    <div class="list-wrap">
        <div class="title">{{ title }}</div>
        <ul class="column-list-item">
            <li v-for="(item,index) in columnData" :key="index" class="hover-class">
                <div class="img">
                    <nuxt-link :to="{path: `/column/${item.id}`}">
                    <img v-lazy="item.main_img_url[0]" alt="" srcset="">
                    </nuxt-link>
                </div>
                <p class="date">{{ formalDate(item.create_time) }}</p>
                <p class="tit"> <nuxt-link :to="{path: `/column/${item.id}`}">{{ item.name }} </nuxt-link></p>
            </li>
        </ul>
        <div class="btn-wrap">
            <nuxt-link :to="{path: '/column', query: {id: curCateId?curCateId:'' }}">
            <div class="btn btn-animate btn-gray">查看全部</div></nuxt-link>
        </div>
    </div>
</template>

<script>
export default {
    props: {
        title: String,
        columnData: Array,
        curCateId: {
            type: Number,
            default: 0
        }
    },
    methods: {
        formalDate(val){
            const index = val.indexOf(' ');
            return val.substring(0,index);
        }
    }
}
</script>

<style lang="less" scoped>

    

    // 列表
    .list-wrap{
        .title{
            margin-bottom: 50px;
            line-height: 1;
            font-size: 28px;
            font-weight: bold;
        }
        .btn-wrap{
            display: flex;
            justify-content: center;
            .btn{
                display: flex;
                justify-content: center;
                align-items: center;
                width: 200px;
                height: 40px;
                font-size: 16px;
                border: 1px solid #707070;
                border-radius: 5px;                
            }
        }
    }
    .column-list-item{
        display: flex;
        li{
            flex: 1;
            margin-bottom: 48px;
            &:nth-child(2){
                .img{
                    background-color: #ddd;
                }
            }
            .img{
                height: 230px;
                background-color: #eee;
                img{
                    width: 100%;
                    height: 100%;
                }
            }
            .date{
                margin: 20px 0 5px;
            }
        }

    }
</style>

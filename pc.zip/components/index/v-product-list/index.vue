<template>
    <div class="list-wrap">
        <div class="title">{{title}}</div>
        <ul class="list-item">
            <li v-for="(item, index) in productData" :key="index" class="hover-class">
                <div class="img">
                    <nuxt-link :to="{path: `/product/${item.id}`}">
                        <img v-lazy="item.main_img_url[0]" alt="">
                    </nuxt-link>
                </div>
                <p class="tit"><nuxt-link :to="{path: `/product/${item.id}`}">{{ item.name }}</nuxt-link></p>
                <p class="price">{{ item.price }}元</p>
            </li>
            <li></li>
            <li></li>
            <li></li>
        </ul>
        <div class="btn-wrap" v-if="showAll">
            <nuxt-link :to="{path: '/product', query: {id: curCateId ? curCateId : 0, name: title}}">
                <span class="btn btn-animate btn-gray">查看全部</span>
            </nuxt-link>
        </div>
    </div>
</template>

<script>
export default {
    props: {
        title: String,
        showAll: {
            type: Boolean,
            default: true
        },
        productData: Array,
        curCateId: {
            type: Number,
            default: 0
        }
    }
}
</script>

<style lang="less" scoped>
    // 列表
    .list-wrap{
        .title{
            margin-bottom: 50px;
            line-height: 1;
            font-size: 28px;
            font-weight: bold;
        }
        .btn-wrap{
            display: flex;
            justify-content: center;
            .btn{
                display: flex;
                justify-content: center;
                align-items: center;
                width: 200px;
                height: 40px;
                font-size: 16px;
                border: 1px solid #707070;
                border-radius: 5px;
            }
        }
    }
    .list-item{
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        li{
            width: 217px;
            margin-bottom: 24px;
            .img{
                height: 217px;
                background-color: #eee;
                img{
                    width: 100%;
                    height: 100%;
                }
            }
            .tit{
                margin: 20px 0 5px;
            }
            .price{
                font-weight: bold;
            }
        }
    }
</style>

<template>
    <div class="about-container">
        <div class="title">唔该理念</div>
        <div class="section">
            <div class="tit">企业故事</div>
            <div class="con">
                <p>重视人形宠物之间的互相联结，舒服自然的色彩，高品质的选材料重视人形宠物之间的互相联结，舒服自然的色彩，高品质的选材料重视人形宠物之间的互相联结，舒服自然的色彩，高品质的选材料</p>
                <p>重视人形宠物之间的互相联结，舒服自然的色彩，高品质的选材料重视人形宠物之间的互相联结，舒服自然的色彩，高品质的选材料重视人形宠物之间的互相联结，舒服自然的色彩，高品质的选材料</p>
            </div>
            <div class="tit">企业愿景</div>
            <div class="con">
                <p>重视人形宠物之间的互相联结，舒服自然的色彩，高品质的选材料重视人形宠物之间的互相联结，舒服自然的色彩，高品质的选材料重视人形宠物之间的互相联结，舒服自然的色彩，高品质的选材料</p>
                <p>重视人形宠物之间的互相联结，舒服自然的色彩，高品质的选材料重视人形宠物之间的互相联结，舒服自然的色彩，高品质的选材料重视人形宠物之间的互相联结，舒服自然的色彩，高品质的选材料</p>
            </div>
            <div class="tit">企业理念</div>
            <div class="con">
                <p>重视人形宠物之间的互相联结，舒服自然的色彩，高品质的选材料重视人形宠物之间的互相联结，舒服自然的色彩，高品质的选材料重视人形宠物之间的互相联结，舒服自然的色彩，高品质的选材料</p>
                <p>重视人形宠物之间的互相联结，舒服自然的色彩，高品质的选材料重视人形宠物之间的互相联结，舒服自然的色彩，高品质的选材料重视人形宠物之间的互相联结，舒服自然的色彩，高品质的选材料</p>
            </div>
        </div>
    </div>
</template>

<script>
export default {

}
</script>

<style lang="less" scoped>
    .about-container{
        display: flex;
        .title{
            flex: 0 0 260px;
            width: 260px;
            font-size: 16px;
            box-sizing: border-box;
            padding-left: 10px;
            font-weight: bold;
        }
        .section{
            flex: 1;
            .tit{
                padding-bottom: 20px;
                margin-bottom: 20px;
                font-size: 28px;
                font-weight: bold;
                border-bottom: 1px solid #707070;
            }
            .con{
                margin-bottom: 80px;
                p{
                    margin-top: 20px;
                }
            }
        }
    }
</style>